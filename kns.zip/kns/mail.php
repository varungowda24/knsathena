<?php

if(isset($_POST["name"]) and isset($_POST["email"]) and isset($_POST["mob"])){
    
    
    
    
$name = $_REQUEST['name'];
$cust_email =  $_REQUEST['email'];
$phone =  $_REQUEST['mob'];
$source ="knsathena.com";

    
    $customerName = rawurlencode($name);
$mobileNumber = rawurlencode($phone);
$emailID = rawurlencode($cust_email);
$source = rawurlencode($source);

// the message
$msg = "Name: ".$_POST["name"]."\nEmail: ".$_POST["email"]."\nMobile: ".$_POST["mob"]."";
// use wordwrap() if lines are longer than 70 characters
// $msg = wordwrap($msg,70);
mail("enquiry@knsathena.com","KNS ATHENA ENQUIRY",$msg);


 $websiteUrl = "http://106.51.65.198:8080/kns/Legal/RestAPI/include/leadPush.php?customerName=".$customerName."&mobileNumber=".$mobileNumber."&emailID=".$emailID."&source=".$source;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $websiteUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $data = curl_exec($ch);
        curl_close($ch);



// send email
    echo '<script>alert("Thank you for reaching to us! we\'ll get back to you at the earliest."); window.location.replace("https://knsathena.com")</script>';
}else{
    echo "ACCESS DENIED";
}

?>